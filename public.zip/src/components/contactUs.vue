<template>
	<div class="inner_pages">
		<navigation></navigation>
		<!-- START Breadcume area -->
		<div class="breadcume our_services innerall">
			<div class="container">
				<div class="breadcume_inner">
					<div class="breadcume_title">
						<h1>Contact Us</h1>
					</div>
				</div>
			</div>
		</div>
		<!-- end Breadcume area -->
		<div class="service_content">
			<div class="container">
				<div class="contact-wrapper row">
					<div class="col-md-6">
						<img src="/assets/d9_images/contactus.png" alt="" title="" style="max-width:100%">
					</div>
					<div class="contact-box col-md-6 form-box">
						<form class="contact-form" >
							<div class="row">
								<div class="col-lg-12">
									<div class="form-group">
										<input class="form-control" id="name" name="name" placeholder="Your Name" type="text" required="">
									</div>
								</div>
								<!-- Col end-->
								<div class="col-lg-12">
									<div class="form-group">
										<input class="form-control " id="Email" name="Email" placeholder="Email" type="text" required="">
									</div>
								</div>
								<div class="col-lg-12">
									<div class="form-group">
										<input class="form-control" id="Phone" name="Phone" placeholder="Phone Number" type="text" required="">
									</div>
								</div>
								<div class="col-lg-12">
									<div class="form-group">
										<textarea class="form-control form-message required-field" id="message" placeholder="Comments" rows="5"></textarea>
									</div>
								</div>
								<!-- Col 12 end-->
							</div>
							<!-- Form row end-->
							<div class="text-right">
								<button class="btn btn_link mt-2" type="submit">Contact US</button>
							</div>
						</form>
						<!-- Form end-->
					</div>
				</div> 
				<div class="row">
					<div class="col-md-4 col-lg-4">
						<div class="inner_contact">
							<div class="ts-contact-info">
								<span class="ts-contact-icon float-left"><i class="icon icon-location-pin"></i></span>
								<div class="ts-contact-content">
									<h3 class="ts-contact-title">Find Us</h3>
									<p>C-1204, A-Wing, STRATUM at Venus Grounds Nr. Jhansi ki Rani statue, Nehru Nagar, Satellite, Ahmedabad, Gujarat 380015</p>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-lg-4">
						<div class="inner_contact">
							<div class="ts-contact-info">
								<span class="ts-contact-icon float-left"><i class="icon icon-phone"></i></span>
								<div class="ts-contact-content">
									<h3 class="ts-contact-title">Call Us</h3>
									<p>+91-756-745-6843<br/>+91-937-468-6975</p>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-lg-4">
						<div class="inner_contact">
							<div class="ts-contact-info last">
								<span class="ts-contact-icon float-left"><i class="icon icon-envelope-open"></i></span>
								<div class="ts-contact-content">
									<h3 class="ts-contact-title">Mail Us</h3>
									<p>hr@d9ithub.com <br/>d9ithub@gmail.com</p>
								</div>
							</div>
						</div>
					</div>
				</div>  
			</div>
		</div>
		<div class="contact_map">
			<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3672.045378429286!2d72.53756100000001!3d23.022106!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xd4bb3cc06ab9bedd!2sStratum%20%40%20Venus%20Grounds!5e0!3m2!1sen!2sin!4v1649320982409!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
		</div>
		<footerarea></footerarea>
	</div>
</template>

<script>
	import navigation from "../components/common/navigation"
	import footerarea from '../components/common/footerarea'
	import AboveFooter from '../components/common/abovefooter'
	export default {
		components: {
			navigation,
			AboveFooter,
			footerarea
		},
		data: () => ({
            show: false
		}),
		mounted(){
			window.scrollTo({
				top: 0,
				behavior: 'smooth',
			});
		}
    };
</script>