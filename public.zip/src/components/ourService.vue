<template>
	<div class="inner_pages">
		<navigation></navigation>
		<!-- START Breadcume area -->
		<div class="breadcume our_services innerall">
			<div class="container">
				<div class="breadcume_inner">
					<div class="breadcume_title">
						<h1 data-aos="zoom-in" data-aos-duration="1200">Our Services</h1>
						<!-- <ul class="nav justify-content-center nav-justified">
							<li class="nav-item">
								<router-link class="nav-link color_white" to="/ourService/webdevelopment">
									<img src="/assets/d9_images/webdevelopment.png" alt="" title="" height="70"><br/>
									Web <br/>Development
								</router-link>
							</li>
							<li class="nav-item">
								<router-link class="nav-link color_white" to="/ourService/webdesign">
									<img src="/assets/d9_images/website_design.png" alt="" title="" height="70"><br/>
									Graphics <br/>Design
								</router-link>
							</li>
							<li class="nav-item">
								<router-link class="nav-link color_white" to="/ourService/cmsandecommerce">
									<img src="/assets/d9_images/ecommerce.png" alt="" title="" height="70"><br/>
									CMS & <br/>Ecommerce
								</router-link>
							</li>
							<li class="nav-item">
								<router-link class="nav-link color_white" to="/ourService/mobileDevelopment">
									<img src="/assets/d9_images/mobile_development.png" alt="" title="" height="70"><br/>
									Mobile <br/>Development
								</router-link>
							</li>
							<li class="nav-item">
								<router-link class="nav-link color_white" to="/ourService/enterpriseSolution">
									<img src="/assets/d9_images/enterprise.png" alt="" title="" height="70"><br/>
									Enterprice <br/>Solutions
								</router-link>
							</li>
							<li class="nav-item">
								<router-link class="nav-link color_white" to="/ourService/hireDedicatedResource">
									<img src="/assets/d9_images/hire_developer.png" alt="" title="" height="70"><br/>
									Hire <br/>Developers
								</router-link>
							</li>
						</ul> -->
					</div>
				</div>
			</div>
		</div>
		<div class="service_content">
			<div class="container">
				<!-- <h2>Our Services</h2> -->
				<div class="row">
					<div class="col-md-4">
						<div class="inner_services" data-aos="fade-right" data-aos-duration="1000">
							<img src="/assets/d9_images/webservices.png" alt="" title="">
							<div class="ts-service-content">
								<span class="ts-service-icon">
									<i class="fas fa-cogs"></i>
								</span>
								<h3 class="service-title">Web Development</h3>
								<p>Build secure and scalable web applications supported by innovative solutions, ingenious methodology and global delivery model. 70+ web projects delivered worldwide.</p>
								<!-- <p><router-link class="link-more" to="/ourService/webdevelopment">Read More <i class="fas fa-long-arrow-alt-right"></i></router-link></p> -->
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="inner_services" data-aos="zoom-out" data-aos-duration="1000">
							<img src="/assets/d9_images/mobileservices.png" alt="" title="">
							<div class="ts-service-content">
								<span class="ts-service-icon">
									<i class="fas fa-mobile-alt"></i>
								</span>
								<h3 class="service-title">Mobile Development</h3>
								<p>Leading mobile (iPhone / iOS, Android) application development companies in India offering mobile apps development services for enterprises and startups - Delivered 50+ native and cross-platform mobile apps.</p>
								<!-- <p><router-link class="link-more" to="/ourService/mobileDevelopment">Read More <i class="fas fa-long-arrow-alt-right"></i></router-link></p> -->
							</div>
						</div>
					</div>					
					<div class="col-md-4">
						<div class="inner_services" data-aos="fade-left" data-aos-duration="1000">
							<img src="/assets/d9_images/ecommerceservices.png" alt="" title="" >
							<div class="ts-service-content">
								<span class="ts-service-icon">
									<i class="fab fa-opencart"></i>
								</span>
								<h3 class="service-title">CMS & Ecommerce</h3>
								<p>Explore Open Source development with custom CMS and E-Commerce Solutions - supporting quick, accurate, and high performance deliverables to improve business ROI.</p>
								<!-- <p><router-link class="link-more" to="/ourService/cmsandecommerce">Read More <i class="fas fa-long-arrow-alt-right"></i></router-link></p> -->
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-4">
						<div class="inner_services" data-aos="fade-right" data-aos-duration="1000">
							<img src="/assets/d9_images/graphicservices.png" alt="" title="">
							<div class="ts-service-content">
								<span class="ts-service-icon">
									<i class="fas fa-palette"></i>
								</span>
								<h3 class="service-title">Graphics & Website Design</h3>
								<p>Leading Graphics & Website Design Company in India having delivered many website with animation<br/><br/></p>
								<!-- <p><router-link class="link-more" to="/ourService/webdesign">Read More <i class="fas fa-long-arrow-alt-right"></i></router-link></p> -->
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="inner_services" data-aos="zoom-out" data-aos-duration="1000">
							<img src="/assets/d9_images/enterprice_solution.png" alt="" title="">
							<div class="ts-service-content">
								<span class="ts-service-icon">
									<i class="far fa-lightbulb"></i>
								</span>
								<h3 class="service-title">Enterprise Solutions</h3>
								<p>Enterprise solutions to transform your business and address key challenges to drive maximum value, accelerate workflows, and improve efficiency.</p>
								<!-- <p><router-link class="link-more" to="/ourService/enterpriseSolution">Read More <i class="fas fa-long-arrow-alt-right"></i></router-link></p> -->
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="inner_services" data-aos="fade-left" data-aos-duration="1000">
							<img src="/assets/d9_images/hireservices.png" alt="" title="" >
							<div class="ts-service-content">
								<span class="ts-service-icon">
									<i class="fas fa-users"></i>
								</span>
								<h3 class="service-title">Hire Dedicated Resources</h3>
								<p>Choose from flexi-hiring models that are guided by proven methodologies and quick turnaround to deliver extraordinary business solution.</p>
								<!-- <p><router-link class="link-more" to="/ourService/hireDedicatedResource">Read More <i class="fas fa-long-arrow-alt-right"></i></router-link></p> -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<footerarea></footerarea>
	</div>
</template>

<script>
	import navigation from "../components/common/navigation"
	import footerarea from '../components/common/footerarea'
	import AboveFooter from '../components/common/abovefooter'
	export default {
		components: {
			navigation,
			AboveFooter,
			footerarea
		},
		data: () => ({
            show: false
		}),
		mounted(){
			window.scrollTo({
				top: 0,
				behavior: 'smooth',
			});
		}
    };
</script>
