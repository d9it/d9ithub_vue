<template>
   <div>
      <section class="call-to-action bg-pattern-3 solid-bg pab-120">
         <div class="container">
            <div class="row text-center">
               <div class="col-lg-12">
                  <h3 class="call-to-action-title">We Offer Financial Strategies &amp; Superior Services</h3>
                  <p>
                     Our mission is to provide quality guidance, build relationships of
                     <br> trust, and develop innovative solutions
                  </p><a class="btn btn-primary" href="">Get Free Quote</a>
               </div>
            </div>
         </div>
      </section>
    </div>
</template>

<script>
	export default {
		components: {
		},
		data: () => ({
            show: false
        }),
    };
</script>
