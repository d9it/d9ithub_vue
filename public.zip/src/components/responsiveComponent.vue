<template>
	<div class="inner_pages">
		<navigation></navigation>
		<div class="breadcume our_services">
			<div class="container">
				<div class="breadcume_inner">
					<div class="breadcume_title">
						<h1>Graphics & Website </h1>
						<ul class="bradcume_nav">
							<li class="nav-item ">
								<router-link class="nav-link color_white" to="/webdesign">
									<img src="/assets/d9_images/webdesign.png" alt="" title="" height="60"><br/>
									Web Design
								</router-link>
							</li>
							<li class="nav-item">
								<router-link class="nav-link color_white" to="/psd">
									<img src="/assets/d9_images/psd.png" alt="" title="" height="60"><br/>
									PSD 
								</router-link>
							</li>
							<li class="nav-item">
								<router-link class="nav-link color_white" to="/logo">
									<img src="/assets/d9_images/logo.png" alt="" title="" height="60"><br/>
									Logo
								</router-link>
							</li>
							<!-- <li class="nav-item">
								<router-link class="nav-link color_white" to="/banner">
									<img src="/assets/d9_images/banner.png" alt="" title="" height="60"><br/>
									Banner
								</router-link>
							</li> -->
							<li class="nav-item active">
								<router-link class="nav-link color_white" to="/responsive">
									<img src="/assets/d9_images/responsive.png" alt="" title="" height="60"><br/>
									Responsive
								</router-link>
							</li>
                            <!-- <li class="nav-item ">
								<router-link class="nav-link color_white" to="/appdesign">
									<img src="/assets/d9_images/mobileapp.png" alt="" title="" height="60"><br/>
									App Design 
								</router-link>
							</li>							 -->
						</ul>
					</div>
				</div>
			</div>
		</div>

		<!-- start All php project -->
			<div class="portfolio_inner odd_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="https://design.nightingalepass.co.uk"  target="_blank">
											<h1>Nightingale Pass</h1>
										</a>
										<p>Welcome to the Nightingale Pass, the universal compliance passport which allows agency nurses to be flexible, be in control of their own compliance details and get into the workforce quicker. </p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
												<li class="nav-item"><i class="fab fa-vuejs"></i>Vue</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="https://design.nightingalepass.co.uk/"  target="_blank">
												<img src="/assets/d9_images/webp/mi_nightanglepass.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner even_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="https://ipm.clicknomics.io/" target="_blank">
												<img src="/assets/d9_images/webp/mi_clicknomic.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="https://ipm.clicknomics.io/" target="_blank">
											<h1>Clicknomics</h1>
										</a>
										<p>clicknomic is an automated marketing reporting tool created to help marketers save hours of work and create their reports in the blink of an eye.</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
												<li class="nav-item"><i class="fab fa-vuejs"></i>Vue</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner odd_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="http://designtool.prettypinswizard.com/"  target="_blank">
											<h1>Pretty Pins Wizard</h1>
										</a>
										<p>Let your`s be evergreen on the Canvas. My Canvas Story is your best destination for customized canvas prints.</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
												<li class="nav-item"><i class="fab fa-vuejs"></i>Vue</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="http://designtool.prettypinswizard.com/"  target="_blank">
												<img src="/assets/d9_images/webp/mi_prettypins.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner even_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="http://canadapetvet.com/" target="_blank">
												<img src="/assets/d9_images/webp/mi_canadapetvet.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="http://canadapetvet.com/" target="_blank">
											<h1>Canadapet Vet</h1>
										</a>
										<p>Canadapet Vet is dedicated to supplying quality pet care products at affordable prices. We care and are dedicated to providing best pet care, always!</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
												<li class="nav-item"><i class="fab fa-vuejs"></i>Vue</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner odd_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="http://budgetpetcart.d9ithub.com/"  target="_blank">
											<h1>Budgetpet Mall</h1>
										</a>
										<p>Budgetpet Mall is dedicated to supplying quality pet care products at affordable prices. We care and are dedicated to providing best pet care, always!</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
												<li class="nav-item"><i class="fab fa-vuejs"></i>Vue</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="http://budgetpetcart.d9ithub.com/"  target="_blank">
												<img src="/assets/d9_images/webp/mi_budgetpetmall.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner even_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="https://mycanvasstory.com/" target="_blank">
												<img src="/assets/d9_images/webp/mi_mycanvas.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="https://mycanvasstory.com/" target="_blank">
											<h1>Mycanvas Story</h1>
										</a>
										<p>Let your`s be evergreen on the Canvas. My Canvas Story is your best destination for customized canvas prints.</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
												<li class="nav-item"><i class="fab fa-vuejs"></i>Vue</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- <div class="portfolio_inner odd_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="https://learnhub360.com/" target="_blank">
											<h1>Axel Training Services</h1>
										</a>
										<p>Our main objectives is to make all our courses / training sessions more efficient and practical for a better understanding of it, providing to all our learners / candidates the knowledge and self-trust which will lead to perform their job safe, correct and efficient.</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
												<li class="nav-item"><i class="fab fa-vuejs"></i>Vue</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>								
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="https://learnhub360.com/" target="_blank">
												<img src="/assets/d9_images/mi_learnhub.png" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div> -->
			<!-- <div class="portfolio_inner even_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="http://workhub360.d9ithub.com/" target="_blank">
												<img src="/assets/d9_images/mi_workhub.png" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="http://workhub360.d9ithub.com/" target="_blank">
											<h1>Workhub360</h1>
										</a>
										<p>We started WorkHub360 because we found ourselves frequently helping new businesses get off the ground. Our team, and partners have years of experience in everything app development to the legalities of company formation. We've made the mistakes... now let us help you avoid them.</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
												<li class="nav-item"><i class="fab fa-vuejs"></i>Vue</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div> -->
			<div class="portfolio_inner odd_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="https://www.samantc.com/" target="_blank">
											<h1>Sama AL Nokhba Training Center</h1>
										</a>
										<p>Sama AL-Nokhba training center provide essential services for the sucess of aspiring ondividuals with direct training or smart training techniques.</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
												<li class="nav-item"><i class="fab fa-vuejs"></i>Vue</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="https://www.samantc.com/" target="_blank">
												<img src="/assets/d9_images/webp/mi_education.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner even_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="http://designtool.pointclickanddesign.com/" target="_blank">
												<img src="/assets/d9_images/point_click.png" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="http://designtool.pointclickanddesign.com/" target="_blank">
											<h1>Point click & Design</h1>
										</a>
										<p>This Point click & design site based in custome texture design. The site offers quality of products for peoples.</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
												<li class="nav-item"><i class="fab fa-vuejs"></i>Vue</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner odd_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="http://www.thepifcoin.com/" target="_blank">
											<h1>Pifcoin</h1>
										</a>
										<p>Pifcoin is a means to track, inspire and most importantly, promote paying acts of kindness forward. The goal is to further advocate the "pay it forward" agenda by physically using a coin passed from one person to the next.</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="http://www.thepifcoin.com/" target="_blank">
												<img src="/assets/d9_images/webp/pifcoin_1.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner even_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="javascript:void(0);">
												<img src="/assets/d9_images/webp/jwm.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="javascript:void(0);">
											<h1>JWM RACING</h1>
											<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. </p>
										</a>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner odd_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="https://one.sprocketmedia.com/" target="_blank">
											<h1>ONE magazine</h1>
										</a>
										<p>ONE Magazine stands firmly at this intersection. A customizable lifestyle magazine, that connects on a deeper level. it`s the perfect complement to your marketing mix.</p>
										<p>You’re in a unique position, at the intersection of the services you provide, and the relationships you build. Where you can inspire lifestyle. Where you can inspire life.</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
												<li class="nav-item"><i class="fab fa-vuejs"></i>Vue</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="https://one.sprocketmedia.com/" target="_blank">
												<img src="/assets/d9_images/webp/mi_onemag.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner even_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="javascript:void(0);">
												<img src="/assets/d9_images/searchninja.png" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="javascript:void(0);">
											<h1>Search.rec Ninja</h1>
										</a>
										<p>One search with instant results across these networks. Low monthly subscription or discount for annual sign ups.</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner odd_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="http://wegov.nyc/" target="_blank">
											<h1>WeGOV.NYC</h1>
										</a>
										<p>This is a directory of New York City’s Capital Budget Commitments. It comes from a 2000+ page PDF document called FY 2019 Adopted Capital Commitment Plan that explain how the city plans to spend capital money over the next 4 years.</p>
										<p>The city will spend approximately $100 billion on capital projects over the next 10 years. Information about these projects, including their geographic locations, should be made publicly available in the city’s open data portal.</p>
										<p>Join our campaign for an open, engaging and effective digital government.</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="http://wegov.nyc/">
												<img src="/assets/d9_images/webp/mi_mygov.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>								
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner even_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="http://ecommerce.d9ithub.com/">
												<img src="/assets/d9_images/webp/mi_epickgo.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="http://ecommerce.d9ithub.com/" target="_blank">
											<h1>EPICKNGO</h1>
										</a>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. </p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
												<li class="nav-item"><i class="fab fa-vuejs"></i>Vue</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner odd_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="javascript:void(0);" target="_blank">
											<h1>ERJAAN SOLUTIONS</h1>
										</a>
										<p>Erjaan is a saudi company specializing in cloud smart surveys solutions aiming to help organizations in business, healthcare and education sectors to make smarter decisions to drive growth by collecting and analyzing the right data from the right sources.</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="javascript:void(0);" target="_blank">
												<img src="/assets/d9_images/webp/mi_erjaan_solution.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner even_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="https://sarapis.org/" target="_blank">
												<img src="/assets/d9_images/webp/mi_sarapis.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="https://sarapis.org/" target="_blank">
											<h1>SARAPIS</h1>
										</a>
										<p>Sarapis is a New York-state incorporated, federally designated 501.c.3 nonprofit organization. Contributions to Sarapis are tax-deductible.</p>
										<p>The organization was formed in 2010 for “charitable and educational purposes,” which it accomplishes “by providing consultations, trainings, and educational resources to nonprofit organizations to help them develop and deploy free/libre/open­source (“FLO”) technologies in order to operate more effectively.”</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-wordpress-simple"></i>Wordpress</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner  odd_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="https://www.jgrobomarketing.com/" target="_blank">
											<h1>JGROBO</h1>
										</a>
										<p>Founded in 2014, JGRobo Marketing, Inc. are leaders in the development of advanced lead marketing automation products and services.  We specialize in the integration of a diverse range of systems into popular CRMs and marketing automation platforms, empowering our clients with the benefits of improved lead, contact validity, cloud telecommunications capabilities, comprehensive reporting, and customized processing.</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-wordpress-simple"></i>Wordpress</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="https://www.jgrobomarketing.com/" target="_blank">
												<img src="/assets/d9_images/webp/mi_jgrobo_marketing.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner  even_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="http://justmydoc.com/" target="_blank">
												<img src="/assets/d9_images/webp/mi_just_my_doc.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="http://justmydoc.com/" target="_blank">
											<h1>JUST MYDOC</h1>
										</a>
										<p>JustMyDoc is the Virtual Patient Medical Home platform that will revolutionize our healthcare system by lowering cost at the consumer level.</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-wordpress-simple"></i>Wordpress</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner  odd_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="https://www.draftanimalpower.org/" target="_blank">
											<h1>DRAFT ANIMAL POWER</h1>
										</a>
										<p>DAPNet is a non-profit organization of full- and part-time farmers, foresters, loggers, teamsters, animal owners, homesteaders, land owners, and folks interested in learning more about any of these activities. Not only are there still people using animals for power, but also there are many who do it for a living or to support their families’ lifestyle in a kind and sustainable manner.</p> 
										<p>The goal of the Draft Animal-Power Network is to highlight ongoing efforts of people throughout the region who are educating, mentoring, and building community around animal-power and renewable land use, providing opportunities for education and networking throughout the year.</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-wordpress-simple"></i>Wordpress</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="https://www.draftanimalpower.org/" target="_blank">
												<img src="/assets/d9_images/webp/mi_draftanimal.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner  even_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="http://bethcliftonproperties.com" target="_blank">
												<img src="/assets/d9_images/webp/mi_beth_clifton.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="http://bethcliftonproperties.com" target="_blank">
											<h1>BETH CLIFTON</h1>
										</a>
										<p>Beth serves as a Real Estate Agent at The Boulevard Company, and specializes in applying her ethics.</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-wordpress-simple"></i>Wordpress</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner  odd_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="http://openskies-tech.com/" target="_blank">
											<h1>OPENSKIES TECH’S</h1>
										</a>
										<p>Openskies Technologies goal is to transition work process from client location to its delivery center, risk free, rapidly and seamlessly. With a carefully designed process life cycle framework, we have formulated a knowledge transfer mechanism “STEP” which brings in the best practices for mapping the processes, identifying the key players, risks involved in every step of the transition cycle.</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-wordpress-simple"></i>Wordpress</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="http://openskies-tech.com/" target="_blank">
												<img src="/assets/d9_images/webp/mi_openskies_tech.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner  even_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="javascript:void(0);" target="_blank">
												<img src="/assets/d9_images/webp/mi_tierra_oceano.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="javascript:void(0);" target="_blank">
											<h1>TIERRA OCEANO</h1>
										</a>
										<p>We strive to make beautiful, lasting products that are eco-friendly, and that you can use with pride.</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-wordpress-simple"></i>Wordpress</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner  odd_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="javascript:void(0);" target="_blank">
											<h1>RENAISSANCE</h1>
										</a>
										<p>Renaissance Studio of Design is a New York based web design company focusing on developing dynamic and cost effective.</p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-wordpress-simple"></i>Wordpress</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="javascript:void(0);" target="_blank">
												<img src="/assets/d9_images/webp/mi_reneissance.webp" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>								
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="portfolio_inner  even_div">
				<div class="inner_responsive">
					<div class="container">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-1"></div>
								<div class="col-lg-5">
									<div class="inner_shadow">
										<div class="image_height">
											<a href="javascript:void(0);" target="_blank">
												<img src="/assets/d9_images/mi_khayaldave.png" alt="" title="" class="pro-img">
											</a>
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="text-cont">
										<a href="javascript:void(0);" target="_blank">
											<h1>Khayal dave</h1>
										</a>
										<p>Khayal Dave Photography, Ahmedabad is headed by a self-made man who was deeply fascinated by the visually striking moments, different culture and beautiful landscapes. He believes that everyone has a story and wishes to create a long-lasting memory out of it. It’s this dedication, connection with his clients and inspiration, that is the most important element of his approach. He specializes in Documentary, Wedding and Travel Photography. He takes one assignment at a time, especially during weddings to do full justice with his work. </p>
									</div>
									<div class="bg1-icon">
										<div class="icon-show">
											<ul class="nav nav-pills nav-justified mt-3">
												<li class="nav-item"><i class="fab fa-wordpress-simple"></i>Wordpress</li>
												<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
												<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
												<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		<!-- end   All php project -->		
  	<footerarea></footerarea>	
  	</div>
</template>
    



<script>
	import navigation from '../components/common/navigation';	
    import footerarea from '../components/common/footerarea'

export default {
  components: {
	navigation,
	footerarea
  },
  data: () => ({
    show: false
  }),
  mounted(){
	window.scrollTo({
		top: 0,
		behavior: 'smooth',
	});
	$(document).ready(function() {
		$('.image_height a').lightbox(); 
	});
  }
  
};



</script>
