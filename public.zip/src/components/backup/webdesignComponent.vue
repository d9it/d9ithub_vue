<template>
  <div class="inner_pages">
    <navigation></navigation>
    <div class="breadcume our_services">
		<div class="container">
			<div class="breadcume_inner">
				<div class="breadcume_title">
					<h1>Graphics Design</h1>
					<ul class="nav justify-content-center nav-justified">
						<li class="nav-item active">
							<router-link class="nav-link color_white" to="/ourService/webdevelopment">
								<img src="/assets/d9_images/webdevelopment.png" alt="" title="" height="70"><br/>
								Web <br/>Development
							</router-link>
						</li>
						<li class="nav-item">
							<router-link class="nav-link color_white" to="/ourService/webdesign">
								<img src="/assets/d9_images/website_design.png" alt="" title="" height="70"><br/>
								Graphics <br/>Design
							</router-link>
						</li>
						<li class="nav-item">
							<router-link class="nav-link color_white" to="/ourService/cmsandecommerce">
								<img src="/assets/d9_images/ecommerce.png" alt="" title="" height="70"><br/>
								CMS & <br/>Ecommerce
							</router-link>
						</li>
						<li class="nav-item">
							<router-link class="nav-link color_white" to="/ourService/mobileDevelopment">
								<img src="/assets/d9_images/mobile_development.png" alt="" title="" height="70"><br/>
								Mobile <br/>Development
							</router-link>
						</li>
						<li class="nav-item">
							<router-link class="nav-link color_white" to="/ourService/enterpriseSolution">
								<img src="/assets/d9_images/enterprise.png" alt="" title="" height="70"><br/>
								Enterprice <br/>Solutions
							</router-link>
						</li>
						<li class="nav-item">
							<router-link class="nav-link color_white" to="/ourService/hireDedicatedResource">
								<img src="/assets/d9_images/hire_developer.png" alt="" title="" height="70"><br/>
								Hire <br/>Developers
							</router-link>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
    <div class="webdesign_services all_services">
        <div class="col-sm-6" style="padding:0px;">
          <div class="right_services"></div>
        </div>
        <div class="col-sm-6 left_services">
            <div class="services_text">
              <h2>Graphic & Website Design </h2>
              <ul>
                  <li><a class="development_menu_tab" href="#website">Website Redesign</a></li>
                  <li><a class="development_menu_tab" href="#responsive">Responsive Website</a></li>
                  <li><a class="development_menu_tab" href="#logo">Logo, Broucher & Banner Design</a></li>
                  <li><a class="development_menu_tab" href="#psd">PSD to HTML Design</a></li>
                  <li><a class="development_menu_tab" href="#template">Template Design</a></li>
                  <li><a class="development_menu_tab" href="#html5">HTML5</a></li>
                  <li><a class="development_menu_tab" href="#css3">CSS3</a></li>
              </ul>
            </div>
        </div>
    </div>

    <!-- website  -->
        <div class="website all_services" id="website">
          <div class="col-sm-6 left_services">
              <div class="services_text">
                <h2>Website Redesign</h2>
                <p>Website re-designing can be a vital step toward success in your business. If you have already a web site, but it does not look as professional or visually appealing as you want, or it/-/-s not performing or effectively addressing your marketing needs as you would like, we can help you by re-design the entire website.</p>

                <ul>
                    <li><a>Overall Web Strategy</a></li>
                    <li><a>Functionality</a></li>
                    <li><a>Usefulness of Content</a></li>
                    <li><a>Overall Graphic Presentation</a></li>
                    <li><a>Search Engine Optimization</a></li>
                </ul>
              </div>
          </div>
          <div class="col-sm-6 right_services"><div class="bg_img"></div></div>
      </div>
    <!-- website  -->

    <!-- responsive  -->
        <div class="responsive all_services" id="responsive">
          <div class="col-sm-6 right_services"><div class="bg_img"></div></div>
          <div class="col-sm-6 left_services">
              <div class="services_text">
                <h2>Responsive Website</h2>
                <p>Responsive website design also replaces the previous need to design a dedicated mobile website for smartphone users. Now, instead of designing multiple websites for different screen sizes, you can design just one website that scales up or down automatically to match the device it’s being viewed on.</p>
                <p>Not just this, mobile friendly websites would rank higher in search engine algorithms. This means that sites that are not mobile-friendly would potentially lose some ground in search engine results because they would not be delivering a good experience to mobile searchers and viewers.</p>
              </div>
          </div>
      </div>
    <!-- responsive  -->

    <!-- Logo, Broucher & Banner Design  -->
        <div class="logo all_services" id="logo">
          <div class="col-sm-6 left_services">
              <div class="services_text">
                <h2>Logo, Broucher & Banner Design</h2>
                <p>Very few companies in the market knows what it takes to create successful designs which convert your efforts into revenue. Experience from a range of innovative professional designing work such as fine art, graphic design, logo design, product or brochure design, Mobile UI and specially which is in the air today is responsive web design and all advanced level of technological ability allows providing clients with top quality response to their requirements.</p>
                <ul>
                    <li><a>Logo Design</a></li>
                    <li><a>Broucher Design</a></li>
                    <li><a>Banner Design</a></li>
                </ul>
              </div>
          </div>
          <div class="col-sm-6 right_services"><div class="bg_img"></div></div>
      </div>
    <!-- Logo, Broucher & Banner Design  -->

    <!-- PSD to HTML Design   -->
      <div class="psd all_services" id="psd">
          <div class="col-sm-6 right_services"><div class="bg_img"></div></div>
          <div class="col-sm-6 left_services">
              <div class="services_text">
                <h2>PSD to HTML Design</h2>
                <p>Considering you want to convert your PSD to HTML5 we can assume you have your Photoshop design handy. Normally the task of converting a PSD to HTML5 can be a difficult one, requiring a basic level of knowledge for clean and valid code. Export Kit takes the headache out of the export process and will save you lots of time and budget with your web projects.</p>
                <p>we provide world-class PSD to HTML services, to make your design, absolutely compatible with multiple web browsers.Websites are everywhere on the web and nowadays people do all their activities only through websites. Business people use their websites to market their brands and their products on the web. Success on the web and increase in sales depends on attracting the users who visit their websites. This, in turn, depends on web designing.</p>
                
              </div>
          </div>
      </div>
    <!-- PSD to HTML Design  -->

    <!-- Template Design  -->
        <div class="template all_services" id="template">
          <div class="col-sm-6 left_services">
              <div class="services_text">
                <h2>Template Design</h2>
                <p>A website template (or web template) is a pre-designed webpage or set of HTML webpages that anyone can use to "plug-in" their own text content and images into to create a website. Usually built with HTML and CSS code, website templates allow anyone to set up a website without having to hire a professional web developer or designer, although, many developers do use website templates to create sites for their clients.</p>
              </div>
          </div>
          <div class="col-sm-6 right_services"><div class="bg_img"></div></div>
      </div>
    <!-- Template Design -->

    <!-- html5 Design  -->
        <div class="html5 all_services" id="html5">
          <div class="col-sm-6 right_services"><div class="bg_img"></div></div>
          <div class="col-sm-6 left_services">
              <div class="services_text">
                <h2>HTML5 Design</h2>
                <p>HTML is the standard markup language for creating Web pages.</p>
                <ul>
                    <li><a>HTML stands for Hyper Text Markup Language</a></li>
                    <li><a>HTML describes the structure of Web pages using markup</a></li>
                    <li><a>HTML elements are the building blocks of HTML pages</a></li>
                    <li><a>HTML elements are represented by tags</a></li>
                    <li><a>HTML tags label pieces of content such as "heading", "paragraph", "table", and so on</a></li>
                    <li><a>Browsers do not display the HTML tags, but use them to render the content of the page</a></li>
                </ul>
              </div>
          </div>
      </div>
    <!-- html5 Design -->

    <!-- css3 Design  -->
        <div class="css3 all_services" id="css3">
          <div class="col-sm-6 left_services">
              <div class="services_text">
                <h2>CSS3 Design</h2>
                <p>CSS is used to define styles for your web pages, including the design, layout and variations in display for different devices and screen sizes. </p>
                <ul>
                    <li><a>CSS stands for Cascading Style Sheets</a></li>
                    <li><a>CSS describes how HTML elements are to be displayed on screen, paper, or in other media</a></li>
                    <li><a>CSS saves a lot of work. It can control the layout of multiple web pages all at once</a></li>
                    <li><a>External stylesheets are stored in CSS files</a></li>
                </ul>
              </div>
          </div>
          <div class="col-sm-6 right_services"><div class="bg_img"></div></div>
      </div>
    <!-- css3 Design -->
  </div>
</template>
    

<script>
import navigation from "../components/navigation";

export default {
  components: {
    navigation
  },
  data: () => ({
    show: false
  }),
  mounted(){
      $(document).ready(function(){
      // Add smooth scrolling to all links
      $(".development_menu_tab").on('click', function(event) {

        // Make sure this.hash has a value before overriding default behavior
        if (this.hash !== "") {
          // Prevent default anchor click behavior
          event.preventDefault();

          // Store hash
          var hash = this.hash;

          // Using jQuery's animate() method to add smooth page scroll
          // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
          $('html, body').animate({
            scrollTop: $(hash).offset().top
          }, 800, function(){
       
            // Add hash (#) to URL when done scrolling (default click behavior)
            // window.location.hash = hash;
          });
        } // End if
      });
    });
  }
  
};
</script>
