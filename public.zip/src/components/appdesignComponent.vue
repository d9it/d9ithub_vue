<template>
	<div class="inner_pages">
		<navigation></navigation>
		<div class="breadcume our_services">
			<div class="container">
				<div class="breadcume_inner">
					<div class="breadcume_title">
						<h1>Graphics & Website </h1>
						<ul class="bradcume_nav">
							<li class="nav-item">
								<router-link class="nav-link color_white" to="/webdesign">
									<img src="/assets/d9_images/webdesign.png" alt="" title="" height="60"><br/>
									Web Design
								</router-link>
							</li>
							<li class="nav-item">
								<router-link class="nav-link color_white" to="/psd">
									<img src="/assets/d9_images/psd.png" alt="" title="" height="60"><br/>
									PSD 
								</router-link>
							</li>
							<li class="nav-item">
								<router-link class="nav-link color_white" to="/logo">
									<img src="/assets/d9_images/logo.png" alt="" title="" height="60"><br/>
									Logo
								</router-link>
							</li>
							<li class="nav-item">
								<router-link class="nav-link color_white" to="/banner">
									<img src="/assets/d9_images/banner.png" alt="" title="" height="60"><br/>
									Banner
								</router-link>
							</li>
							<li class="nav-item">
								<router-link class="nav-link color_white" to="/responsive">
									<img src="/assets/d9_images/responsive.png" alt="" title="" height="60"><br/>
									Responsive
								</router-link>
							</li>
                            <li class="nav-item active">
								<router-link class="nav-link color_white" to="/appdesign">
									<img src="/assets/d9_images/mobileapp.png" alt="" title="" height="60"><br/>
									App Design 
								</router-link>
							</li>							
						</ul>
					</div>
				</div>
			</div>
		</div>

		<!-- start All php project -->	
		<div class="container">
			<div class="portfolio_inner">
				<div class="row">
					<div class="col-md-4">
						<div class="inner_shadow">
							<div class="image_height">
								<a href="javascript:void(0)">
									<img src="/assets/d9_images/webp/point_click.webp" alt="" title="" class="pro-img">
								</a>
							</div>
							<div class="hover-block">
								<div class="text-cont">
									<div class="bg-rotate">
										<a href="javascript:void(0)" target="_blank" class="info-icon ">
											<img src="/assets/d9_images/webdevelopment.png" alt="" class="rotate-img-diag" width="40">
										</a>
									</div>
									<a href="javascript:void(0)" target="_blank">
										<h1>Point click & Design</h1>
										<p>This EpickNgo site based in UAE. The site offers quality of products for peoples.</p>
									</a>
								</div>
								<div class="bg1-icon">
									<div class="icon-show">
										<h5>Technology</h5>
										<ul class="nav nav-pills nav-justified">
											<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
											<li class="nav-item"><i class="fab fa-vuejs"></i>Vue</li>
											<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
											<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
											<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="inner_shadow">
							<div class="image_height">
								<a href="javascript:void(0)">
									<img src="/assets/d9_images/webp/pifcoin.webp" alt="" title="" class="pro-img">
								</a>
							</div>
							<div class="hover-block">
								<div class="text-cont">
									<div class="bg-rotate">
										<a href="javascript:void(0)" target="_blank" class="info-icon ">
											<img src="/assets/d9_images/webdevelopment.png" alt="" class="rotate-img-diag" width="40">
										</a>
									</div>
									<a href="javascript:void(0)" target="_blank">
										<h1>pifcoin</h1>
										<p>This EpickNgo site based in UAE. The site offers quality of products for peoples.</p>
									</a>
								</div>
								<div class="bg1-icon">
									<div class="icon-show">
										<h5>Technology</h5>
										<ul class="nav nav-pills nav-justified">
											<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
											<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
											<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
											<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="inner_shadow">
							<div class="image_height">
								<a href="javascript:void(0)">
									<img src="/assets/d9_images/webp/epickgo.webp" alt="" title="" class="pro-img">
								</a>
							</div>
							<div class="hover-block">
								<div class="text-cont">
									<div class="bg-rotate">
										<a href="javascript:void(0)" target="_blank" class="info-icon ">
											<img src="/assets/d9_images/webdevelopment.png" alt="" class="rotate-img-diag" width="40">
										</a>
									</div>
									<a href="javascript:void(0)" target="_blank">
										<h1>EPICKNGO</h1>
										<p>This EpickNgo site based in UAE. The site offers quality of products for peoples.</p>
									</a>
								</div>
								<div class="bg1-icon">
									<div class="icon-show">
										<h5>Technology</h5>
										<ul class="nav nav-pills nav-justified">
											<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
											<li class="nav-item"><i class="fab fa-vuejs"></i>Vue</li>
											<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
											<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
											<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="inner_shadow">
							<div class="image_height">
								<a href="javascript:void(0)">
									<img src="/assets/d9_images/jwm.jpg" alt="" title="" class="pro-img">
								</a>
							</div>
							<div class="hover-block">
								<div class="text-cont">
									<div class="bg-rotate">
										<a href="javascript:void(0)" target="_blank" class="info-icon ">
											<img src="/assets/d9_images/webdevelopment.png" alt="" class="rotate-img-diag" width="40">
										</a>
									</div>
									<a href="javascript:void(0)" target="_blank">
										<h1>jwm racing</h1>
										<p>This EpickNgo site based in UAE. The site offers quality of products for peoples.</p>
									</a>
								</div>
								<div class="bg1-icon">
									<div class="icon-show">
										<h5>Technology</h5>
										<ul class="nav nav-pills nav-justified">
											<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
											<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
											<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
											<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="inner_shadow">
							<div class="image_height">
								<a href="javascript:void(0)">
									<img src="/assets/d9_images/socialmedia.jpg" alt="" title="" class="pro-img">
								</a>
							</div>
							<div class="hover-block">
								<div class="text-cont">
									<div class="bg-rotate">
										<a href="javascript:void(0)" target="_blank" class="info-icon ">
											<img src="/assets/d9_images/webdevelopment.png" alt="" class="rotate-img-diag" width="40">
										</a>
									</div>
									<a href="javascript:void(0)" target="_blank">
										<h1>Search.rec Ninja</h1>
										<p>This EpickNgo site based in UAE. The site offers quality of products for peoples.</p>
									</a>
								</div>
								<div class="bg1-icon">
									<div class="icon-show">
										<h5>Technology</h5>
										<ul class="nav nav-pills nav-justified">
											<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
											<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
											<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
											<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="inner_shadow">
							<div class="image_height">
								<a href="javascript:void(0)">
									<img src="/assets/d9_images/webp/mygov.webp" alt="" title="" class="pro-img">
								</a>
							</div>
							<div class="hover-block">
								<div class="text-cont">
									<div class="bg-rotate">
										<a href="javascript:void(0)" target="_blank" class="info-icon ">
											<img src="/assets/d9_images/webdevelopment.png" alt="" class="rotate-img-diag" width="40">
										</a>
									</div>
									<a href="javascript:void(0)" target="_blank">
										<h1>MYGOV.NYC</h1>
										<p>We believe that a path to a more effective NYC government, one that produces better and projects and services.</p>
									</a>
								</div>
								<div class="bg1-icon">
									<div class="icon-show">
										<h5>Technology</h5>
										<ul class="nav nav-pills nav-justified">
											<li class="nav-item"><i class="fab fa-wordpress-simple"></i>Wordpress</li>
											<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
											<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
											<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="inner_shadow">
							<div class="image_height">
								<a href="javascript:void(0)">
									<img src="/assets/d9_images/webp/erjaan_solution.webp" alt="" title="" class="pro-img">
								</a>
							</div>
							<div class="hover-block">
								<div class="text-cont">
									<div class="bg-rotate">
										<a href="javascript:void(0)" target="_blank" class="info-icon ">
											<img src="/assets/d9_images/webdevelopment.png" alt="" class="rotate-img-diag" width="40">
										</a>
									</div>
									<a href="javascript:void(0)" target="_blank">
										<h1>ERJAAN SOLUTIONS</h1>
										<p>Leading mobile (iPhone / iOS, Android) application development companies in India offering mobile apps development services.</p>
									</a>
								</div>
								<div class="bg1-icon">
									<div class="icon-show">
										<h5>Technology</h5>
										<ul class="nav nav-pills nav-justified">
											<li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
											<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
											<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
											<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="inner_shadow">
							<div class="image_height">
								<a href="javascript:void(0)">
									<img src="/assets/d9_images/webp/jgrobo_marketing.webp" alt="" title="" class="pro-img">
								</a>
							</div>
							<div class="hover-block">
								<div class="text-cont">
									<div class="bg-rotate">
										<a href="javascript:void(0)" target="_blank" class="info-icon ">
											<img src="/assets/d9_images/webdevelopment.png" alt="" class="rotate-img-diag" width="40">
										</a>
									</div>
									<a href="javascript:void(0)" target="_blank">
										<h1>JGROBO</h1>
										<p>Founded in 2014, we are industry leaders in the development of marketing automation systems.</p>
									</a>
								</div>
								<div class="bg1-icon">
									<div class="icon-show">
										<h5>Technology</h5>
										<ul class="nav nav-pills nav-justified">
											<li class="nav-item"><i class="fab fa-wordpress-simple"></i>Wordpress</li>
											<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
											<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
											<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="inner_shadow">
							<div class="image_height">
								<a href="javascript:void(0)">
									<img src="/assets/d9_images/webp/sarapis.webp" alt="" title="" class="pro-img">
								</a>
							</div>
							<div class="hover-block">
								<div class="text-cont">
									<div class="bg-rotate">
										<a href="javascript:void(0)" target="_blank" class="info-icon ">
											<img src="/assets/d9_images/webdevelopment.png" alt="" class="rotate-img-diag" width="40">
										</a>
									</div>
									<a href="javascript:void(0)" target="_blank">
										<h1>SARAPIS</h1>
										<p>Sarapis is a New York-state incorporated, federally designated 501.c.3 nonprofit organization.</p>
									</a>
								</div>
								<div class="bg1-icon">
									<div class="icon-show">
										<h5>Technology</h5>
										<ul class="nav nav-pills nav-justified">
											<li class="nav-item"><i class="fab fa-wordpress-simple"></i>Wordpress</li>
											<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
											<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
											<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="inner_shadow">
							<div class="image_height">
								<a href="javascript:void(0)">
									<img src="/assets/d9_images/webp/just_my_doc.webp" alt="" title="" class="pro-img">
								</a>
							</div>
							<div class="hover-block">
								<div class="text-cont">
									<div class="bg-rotate">
										<a href="javascript:void(0)" target="_blank" class="info-icon ">
											<img src="/assets/d9_images/webdevelopment.png" alt="" class="rotate-img-diag" width="40">
										</a>
									</div>
									<a href="javascript:void(0)" target="_blank">
										<h1>JUST MYDOC</h1>
										<p>JustMyDoc is the Virtual Patient Medical Home platform that will revolutionize our healthcare system by lowering cost at the consumer level.</p>
									</a>
								</div>
								<div class="bg1-icon">
									<div class="icon-show">
										<h5>Technology</h5>
										<ul class="nav nav-pills nav-justified">
											<li class="nav-item"><i class="fab fa-wordpress-simple"></i>Wordpress</li>
											<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
											<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
											<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="inner_shadow">
							<div class="image_height">
								<a href="javascript:void(0)">
									<img src="/assets/d9_images/webp/tierra_oceano.webp" alt="" title="" class="pro-img">
								</a>
							</div>
							<div class="hover-block">
								<div class="text-cont">
									<div class="bg-rotate">
										<a href="javascript:void(0)" target="_blank" class="info-icon ">
											<img src="/assets/d9_images/webdevelopment.png" alt="" class="rotate-img-diag" width="40">
										</a>
									</div>
									<a href="javascript:void(0)" target="_blank">
										<h1>TIERRA OCEANO</h1>
										<p>We strive to make beautiful, lasting products that are eco-friendly, and that you can use with pride.</p>
									</a>
								</div>
								<div class="bg1-icon">
									<div class="icon-show">
										<h5>Technology</h5>
										<ul class="nav nav-pills nav-justified">
											<li class="nav-item"><i class="fab fa-wordpress-simple"></i>Wordpress</li>
											<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
											<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
											<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="inner_shadow">
							<div class="image_height">
								<a href="javascript:void(0)">
									<img src="/assets/d9_images/webp/openskies_tech.webp" alt="" title="" class="pro-img">
								</a>
							</div>
							<div class="hover-block">
								<div class="text-cont">
									<div class="bg-rotate">
										<a href="javascript:void(0)" target="_blank" class="info-icon ">
											<img src="/assets/d9_images/webdevelopment.png" alt="" class="rotate-img-diag" width="40">
										</a>
									</div>
									<a href="javascript:void(0)" target="_blank">
										<h1>OPENSKIES TECH’S</h1>
										<p>Openskies Tech’s goal is to transition work process from client location to its delivery center, risk free, rapidly and seamlessly.</p>
									</a>
								</div>
								<div class="bg1-icon">
									<div class="icon-show">
										<h5>Technology</h5>
										<ul class="nav nav-pills nav-justified">
											<li class="nav-item"><i class="fab fa-wordpress-simple"></i>Wordpress</li>
											<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
											<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
											<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="inner_shadow">
							<div class="image_height">
								<a href="javascript:void(0)">
									<img src="/assets/d9_images/webp/reneissance.webp" alt="" title="" class="pro-img">
								</a>
							</div>
							<div class="hover-block">
								<div class="text-cont">
									<div class="bg-rotate">
										<a href="javascript:void(0)" target="_blank" class="info-icon ">
											<img src="/assets/d9_images/webdevelopment.png" alt="" class="rotate-img-diag" width="40">
										</a>
									</div>
									<a href="javascript:void(0)" target="_blank">
										<h1>RENAISSANCE</h1>
										<p>Renaissance Studio of Design is a New York based web design company focusing on developing dynamic and cost effective.</p>
									</a>
								</div>
								<div class="bg1-icon">
									<div class="icon-show">
										<h5>Technology</h5>
										<ul class="nav nav-pills nav-justified">
											<li class="nav-item"><i class="fab fa-wordpress-simple"></i>Wordpress</li>
											<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
											<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
											<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					<div class="col-md-4">
						<div class="inner_shadow">
							<div class="image_height">
								<a href="javascript:void(0)">
									<img src="/assets/d9_images/webp/beth_clifton.webp" alt="" title="" class="pro-img">
								</a>
							</div>
							<div class="hover-block">
								<div class="text-cont">
									<div class="bg-rotate">
										<a href="javascript:void(0)" target="_blank" class="info-icon ">
											<img src="/assets/d9_images/webdevelopment.png" alt="" class="rotate-img-diag" width="40">
										</a>
									</div>
									<a href="javascript:void(0)" target="_blank">
										<h1>BETH CLIFTON</h1>
										<p>Beth serves as a Real Estate Agent at The Boulevard Company, and specializes in applying her ethics.</p>
									</a>
								</div>
								<div class="bg1-icon">
									<div class="icon-show">
										<h5>Technology</h5>
										<ul class="nav nav-pills nav-justified">
											<li class="nav-item"><i class="fab fa-wordpress-simple"></i>Wordpress</li>
											<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
											<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
											<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					<div class="col-md-4">
						<div class="inner_shadow">
							<div class="image_height">
								<a href="javascript:void(0)">
									<img src="/assets/d9_images/webp/draft_animal_power.webp" alt="" title="" class="pro-img">
								</a>
							</div>
							<div class="hover-block">
								<div class="text-cont">
									<div class="bg-rotate">
										<a href="javascript:void(0)" target="_blank" class="info-icon ">
											<img src="/assets/d9_images/webdevelopment.png" alt="" class="rotate-img-diag" width="40">
										</a>
									</div>
									<a href="javascript:void(0)" target="_blank">
										<h1>DRAFT ANIMAL POWER</h1>
										<p>The goal of the Draft Animal-Power Network is to provide year-round educational and networking opportunities.</p>
									</a>
								</div>
								<div class="bg1-icon">
									<div class="icon-show">
										<h5>Technology</h5>
										<ul class="nav nav-pills nav-justified">
											<li class="nav-item"><i class="fab fa-wordpress-simple"></i>Wordpress</li>
											<li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
											<li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
											<li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>	
			</div>
		</div>
		<!-- end   All php project -->		
  		<footerarea></footerarea>	
  	</div>
</template>
    



<script>
	import navigation from '../components/common/navigation';	
    import footerarea from '../components/common/footerarea'

export default {
  components: {
	navigation,
	footerarea
  },
  data: () => ({
    show: false
  }),
  mounted(){
	window.scrollTo({
		top: 0,
		behavior: 'smooth',
	});
  }
  
};



</script>
