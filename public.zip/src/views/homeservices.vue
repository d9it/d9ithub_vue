<template>
    <div>
        <div id="ourService" class="height_fixed"></div>
        <div class="home_services">
            <div class="services_warpper">
                <div class="container py-0">
                    <div class="homeservice_content text-center">
                        <p class="text_sub" data-aos="zoom-in" data-aos-duration="1300">Services</p>
                    </div>
                    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="5"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <div class="home_innerservices home_webdevelopment slide_active">
                                    <div class="services_item_left">
                                        <div class="homeservice_content">
                                            <h1 class="text_big" data-aos="zoom-in-up" data-aos-duration="1500">Web<br/>Development</h1>
                                            <p class="text_normal" data-aos="fade-right" data-aos-duration="1500">Build secure and scalable web applications supported by innovative solutions, ingenious methodology and global delivery model. 70+ web projects delivered worldwide.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="home_innerservices home_webdevelopment slide_active" >
                                    <div class="services_item_left">
                                        <div class="homeservice_content">
                                            <h1 class="text_big" data-aos="zoom-in-up" data-aos-duration="1500">Graphic <br/>Design</h1>
                                            <p class="text_normal" data-aos="fade-right" data-aos-duration="1500">Leading Graphics & Website Design Company in India having delivered many website with animation</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="home_innerservices home_webdevelopment slide_active">
                                    <div class="services_item_left">
                                        <div class="homeservice_content">
                                            <h1 class="text_big" data-aos="zoom-in-up" data-aos-duration="1500">CMS &<br/>Ecommerce</h1>
                                            <p class="text_normal" data-aos="fade-right" data-aos-duration="1500">Explore Open Source development with custom CMS and E-Commerce Solutions - supporting quick, accurate, and high performance deliverables to improve business ROI.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="home_innerservices home_webdevelopment slide_active">
                                    <div class="services_item_left">
                                        <div class="homeservice_content">
                                            <h1 class="text_big" data-aos="zoom-in-up" data-aos-duration="1500">Mobile<br/>Development</h1>
                                            <p class="text_normal" data-aos="fade-right" data-aos-duration="1500">Leading mobile (iPhone / iOS, Android) application development companies in India offering mobile apps development services for enterprises and startups - Delivered 50+ native and cross-platform mobile apps.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="home_innerservices home_webdevelopment slide_active">
                                    <div class="services_item_left">
                                        <div class="homeservice_content">
                                            <h1 class="text_big" data-aos="zoom-in-up" data-aos-duration="1500">Enterprise<br/>Solutions</h1>
                                            <p class="text_normal" data-aos="fade-right" data-aos-duration="1500">Enterprise solutions to transform your business and address key challenges to drive maximum value, accelerate workflows, and improve efficiency.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="home_innerservices home_webdevelopment slide_active">
                                    <div class="services_item_left">
                                        <div class="homeservice_content">
                                            <h1 class="text_big" data-aos="zoom-in-up" data-aos-duration="1500">Hire Dedicated<br/>Resources</h1>
                                            <p class="text_normal" data-aos="fade-right" data-aos-duration="1500">Enterprise solutions to transform your business and address key challenges to drive maximum value, accelerate workflows, and improve efficiency.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                            <i class="fas fa-long-arrow-alt-left"></i>
                        </a>
                        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                            <i class="fas fa-long-arrow-alt-right"></i>
                        </a>
                    </div>
                    <div class="decor-text decor-text-1">Services</div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        components: {
        },
        data: () => ({
            show: false
        }),
        mounted(){}
    };
    
</script>
