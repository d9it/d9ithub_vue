<template>
	<!-- start slider area -->
	<div>
		<div class="home_mainslider">
			<div id="homecarouselslider" class="carousel slide" data-ride="carousel">
				<div class="container">
					<div class="carousel-inner">
						<div class="carousel-item active">
							<div class="row">
								<div class="col-md-6 homeslider_text" data-aos="zoom-in" data-aos-duration="1000">
									<div class="innerslider_text">
										<h1>Web <br/>Development</h1>
										<p>Build secure and scalable web applications supported by innovative solutions, ingenious methodology and global delivery model. 70+ web projects delivered worldwide.</p>
										<router-link class="btn_link" to="/">Learn More
											<span class="blob-btn__inner">
												<span class="blob-btn__blobs">
													<span class="blob-btn__blob"></span>
													<span class="blob-btn__blob"></span>
													<span class="blob-btn__blob"></span>
													<span class="blob-btn__blob"></span>
												</span>
											</span>
										</router-link>
									</div>
								</div>
								<div class="col-md-6 homeslider_img" data-aos="fade-left" data-aos-duration="1000">
									<img src="/assets/d9_images/web_development.png" alt="" title="" >
								</div>
							</div> 
						</div>
						<div class="carousel-item">
							<div class="row">
								<div class="col-md-6 homeslider_text" data-aos="zoom-in" data-aos-duration="1000">
									<div class="innerslider_text">
										<h1>CMS & Ecommerce <br/>Development</h1>
										<p>Explore Open Source development with custom CMS and E-Commerce Solutions - supporting quick, accurate, and high performance deliverables to improve business ROI.</p>
										<router-link class="btn_link" to="/">Learn More
											<span class="blob-btn__inner">
												<span class="blob-btn__blobs">
													<span class="blob-btn__blob"></span>
													<span class="blob-btn__blob"></span>
													<span class="blob-btn__blob"></span>
													<span class="blob-btn__blob"></span>
												</span>
											</span>
										</router-link> 
									</div>
								</div>
								<div class="col-md-6 homeslider_img" data-aos="fade-left" data-aos-duration="1000">
									<img src="/assets/d9_images/ecommerce_cms.png" alt="" title="">
								</div>
							</div> 
						</div>
						<div class="carousel-item">
							<div class="row">
								<div class="col-md-6 homeslider_text" data-aos="zoom-in" data-aos-duration="1000">
									<div class="innerslider_text">
										<h1>Graphics & Website <br/>Design</h1>
										<p>Leading Graphics & Website Design Company in India having delivered many website with animation. </p>
										<router-link class="btn_link" to="/">Learn More
											<span class="blob-btn__inner">
												<span class="blob-btn__blobs">
													<span class="blob-btn__blob"></span>
													<span class="blob-btn__blob"></span>
													<span class="blob-btn__blob"></span>
													<span class="blob-btn__blob"></span>
												</span>
											</span>
										</router-link> 
									</div>
								</div>
								<div class="col-md-6 homeslider_img" data-aos="fade-left" data-aos-duration="1000">
									<img src="/assets/d9_images/graphics.png" alt="" title="">
								</div>
							</div> 
						</div>
						<div class="carousel-item">
							<div class="row">
								<div class="col-md-6 homeslider_text" data-aos="zoom-in" data-aos-duration="1000">
									<div class="innerslider_text">
										<h1>Mobile <br/>Development</h1>
										<p>Leading mobile (iPhone / iOS, Android) application development companies in India offering mobile apps development services for enterprises and startups - Delivered 50+ native and cross-platform mobile apps.</p>
										<router-link class="btn_link" to="/">Learn More
											<span class="blob-btn__inner">
												<span class="blob-btn__blobs">
													<span class="blob-btn__blob"></span>
													<span class="blob-btn__blob"></span>
													<span class="blob-btn__blob"></span>
													<span class="blob-btn__blob"></span>
												</span>
											</span>
										</router-link> 
									</div>
								</div>
								<div class="col-md-6 homeslider_img" data-aos="fade-left" data-aos-duration="1000">
									<img src="/assets/d9_images/mobile_app.png" alt="" title="">
								</div>
							</div> 
						</div>
						<div class="carousel-item">
							<div class="row">
								<div class="col-md-6 homeslider_text" data-aos="zoom-in" data-aos-duration="1000">
									<div class="innerslider_text">
										<h1>Hire Dedicated <br/>Resources</h1>
										<p>Choose from flexi-hiring models that are guided by proven methodologies and quick turnaround to deliver extraordinary business solution.</p>
										<router-link class="btn_link" to="/">Learn More
											<span class="blob-btn__inner">
												<span class="blob-btn__blobs">
													<span class="blob-btn__blob"></span>
													<span class="blob-btn__blob"></span>
													<span class="blob-btn__blob"></span>
													<span class="blob-btn__blob"></span>
												</span>
											</span>
										</router-link> 
									</div>
								</div>
								<div class="col-md-6 homeslider_img" data-aos="fade-left" data-aos-duration="1000">
									<img src="/assets/d9_images/hire_developers.png" alt="" title="">
								</div>
							</div> 
						</div>
						<div class="carousel-item">
							<div class="row">
								<div class="col-md-6 homeslider_text" data-aos="zoom-in" data-aos-duration="1000">
									<div class="innerslider_text">
										<h1>Enterprise<br/>Solutions</h1>
										<p>Enterprise solutions to transform your business and address key challenges to drive maximum value, accelerate workflows, and improve efficiency.</p>
										<router-link class="btn_link" to="/">Learn More
											<span class="blob-btn__inner">
												<span class="blob-btn__blobs">
													<span class="blob-btn__blob"></span>
													<span class="blob-btn__blob"></span>
													<span class="blob-btn__blob"></span>
													<span class="blob-btn__blob"></span>
												</span>
											</span>
										</router-link> 
									</div>
								</div>
								<div class="col-md-6 homeslider_img" data-aos="fade-left" data-aos-duration="1000">
									<img src="/assets/d9_images/enterprise_solition.png" alt="" title="">
								</div>
							</div> 
						</div>
					</div>
				</div>
				<a class="carousel-control-prev" href="#homecarouselslider" role="button" data-slide="prev">
					<i class="fas fa-long-arrow-alt-left"></i>
				</a>
				<a class="carousel-control-next" href="#homecarouselslider" role="button" data-slide="next">
					<i class="fas fa-long-arrow-alt-right"></i>
				</a>
			</div>
		</div>
	</div>
   <!-- end slider area -->
</template>

<script>
export default {
	data: () => ({
		show: false
	}),
	mounted() {
		$(document).ready(function() {
		// custom initialization
		
		$('.scroll-top').on('click', function(e) {
			e.preventDefault();
			$('html, body').animate({ scrollTop: 0 }, 'slow');
		});
	});

	}
};
</script>