<template>
    <div>
        <div id="portfolio" class="height_fixed"></div>
        <div class="portfolio_warpper">
            <div class="row m-0">
                <div class="container">
                    <p class="text_background">Portfolio</p>
                    <p class="portfolio_title" data-aos="zoom-in" data-aos-duration="1000">Portfolio</p>
                    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <div class="row">
                                    <div class="col-md-6 portfolio_item_right">
                                        <img src="/assets/d9_images/webp/mi_nightanglepass.webp" alt="" title="" data-aos="zoom-in-left" data-aos-duration="1500">
                                    </div>
                                    <div class="col-md-6 portfolio_item_left">
                                        <div class="homeportfolio_content">
                                            <h1 class="text_big" data-aos="fade-left" data-aos-duration="1000">Nightingale Pass</h1>
                                            <p class="text_normal" data-aos="fade-left" data-aos-duration="1200">Welcome to the Nightingale Pass, the universal compliance passport which allows agency nurses to be flexible, be in control of their own compliance details and get into the workforce quicker. <br/></p>
                                            <p class="text_sub" data-aos="fade-left" data-aos-duration="1500"><br/>Used Technology</p>
                                            <p class="text_normal" data-aos="fade-left" data-aos-duration="1800">
                                                <ul class="nav nav-pills nav-justified">
                                                    <li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
                                                    <li class="nav-item"><i class="fab fa-vuejs"></i>Vue Js</li>
                                                    <li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
                                                    <li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
                                                    <li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
                                                </ul>
                                            </p>    
                                        </div>
                                    </div>
                                </div> 
                            </div>
                            <div class="carousel-item">
                                <div class="row">
                                    <div class="col-md-6 portfolio_item_right">
                                        <img src="/assets/d9_images/webp/mi_clicknomic.webp" alt="" title="">
                                    </div>
                                    <div class="col-md-6 portfolio_item_left">
                                        <div class="homeportfolio_content">
                                            <h1 class="text_big" data-aos="fade-left" data-aos-duration="1000">Clicknomics</h1>
                                            <p class="text_normal" data-aos="fade-left" data-aos-duration="1200">clicknomic is an automated marketing reporting tool created to help marketers save hours of work and create their reports in the blink of an eye.<br/></p>
                                            <p class="text_sub" data-aos="fade-left" data-aos-duration="1500"><br/>Used Technology</p>
                                            <p class="text_normal" data-aos="fade-left" data-aos-duration="1800">
                                                <ul class="nav nav-pills nav-justified">
                                                    <li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
                                                    <li class="nav-item"><i class="fab fa-vuejs"></i>Vue Js</li>
                                                    <li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
                                                    <li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
                                                    <li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
                                                </ul>
                                            </p>    
                                        </div>
                                    </div>
                                </div> 
                            </div>
                            <div class="carousel-item">
                                <div class="row">
                                    <div class="col-md-6 portfolio_item_right">
                                        <img src="/assets/d9_images/webp/mi_prettypins.webp" alt="" title="">
                                    </div>
                                    <div class="col-md-6 portfolio_item_left">
                                        <div class="homeportfolio_content">
                                            <h1 class="text_big" data-aos="fade-left" data-aos-duration="1000">Pretty Pins Wizard</h1>
                                            <p class="text_normal" data-aos="fade-left" data-aos-duration="1200">Let your`s be evergreen on the Canvas. My Canvas Story is your best destination for customized canvas prints.<br/></p>
                                            <p class="text_sub" data-aos="fade-left" data-aos-duration="1500"><br/>Used Technology</p>
                                            <p class="text_normal" data-aos="fade-left" data-aos-duration="1800">
                                                <ul class="nav nav-pills nav-justified">
                                                    <li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
                                                    <li class="nav-item"><i class="fab fa-vuejs"></i>Vue Js</li>
                                                    <li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
                                                    <li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
                                                    <li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
                                                </ul>
                                            </p>    
                                        </div>
                                    </div>
                                </div> 
                            </div>
                            <div class="carousel-item">
                                <div class="row">
                                    <div class="col-md-6 portfolio_item_right">
                                        <img src="/assets/d9_images/webp/mi_canadapetvet.webp" alt="" title="">
                                    </div>
                                    <div class="col-md-6 portfolio_item_left">
                                        <div class="homeportfolio_content">
                                            <h1 class="text_big" data-aos="fade-left" data-aos-duration="1000">Canadapet Vet</h1>
                                            <p class="text_normal" data-aos="fade-left" data-aos-duration="1200">Canadapet Vet is dedicated to supplying quality pet care products at affordable prices. We care and are dedicated to providing best pet care, always!<br/></p>
                                            <p class="text_sub" data-aos="fade-left" data-aos-duration="1500"><br/>Used Technology</p>
                                            <p class="text_normal" data-aos="fade-left" data-aos-duration="1800">
                                                <ul class="nav nav-pills nav-justified">
                                                    <li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
                                                    <li class="nav-item"><i class="fab fa-vuejs"></i>Vue Js</li>
                                                    <li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
                                                    <li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
                                                    <li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
                                                </ul>
                                            </p>    
                                        </div>
                                    </div>
                                </div> 
                            </div>
                            <div class="carousel-item">
                                <div class="row">
                                    <div class="col-md-6 portfolio_item_right">
                                        <img src="/assets/d9_images/webp/mi_budgetpetmall.webp" alt="" title="">
                                    </div>
                                    <div class="col-md-6 portfolio_item_left">
                                        <div class="homeportfolio_content">
                                            <h1 class="text_big" data-aos="fade-left" data-aos-duration="1000">Budgetpet Mall</h1>
                                            <p class="text_normal" data-aos="fade-left" data-aos-duration="1200">Budgetpet Mall is dedicated to supplying quality pet care products at affordable prices. We care and are dedicated to providing best pet care, always!<br/></p>
                                            <p class="text_sub" data-aos="fade-left" data-aos-duration="1500"><br/>Used Technology</p>
                                            <p class="text_normal" data-aos="fade-left" data-aos-duration="1800">
                                                <ul class="nav nav-pills nav-justified">
                                                    <li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
                                                    <li class="nav-item"><i class="fab fa-vuejs"></i>Vue Js</li>
                                                    <li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
                                                    <li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
                                                    <li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
                                                </ul>
                                            </p>    
                                        </div>
                                    </div>
                                </div> 
                            </div>
                            <div class="carousel-item">
                                <div class="row">
                                    <div class="col-md-6 portfolio_item_right">
                                        <img src="/assets/d9_images/webp/mi_mycanvas.webp" alt="" title="">
                                    </div>
                                    <div class="col-md-6 portfolio_item_left">
                                        <div class="homeportfolio_content">
                                            <h1 class="text_big" data-aos="fade-left" data-aos-duration="1000">Mycanvas Story</h1>
                                            <p class="text_normal" data-aos="fade-left" data-aos-duration="1200">Let your`s be evergreen on the Canvas. My Canvas Story is your best destination for customized canvas prints.<br/></p>
                                            <p class="text_sub" data-aos="fade-left" data-aos-duration="1500"><br/>Used Technology</p>
                                            <p class="text_normal" data-aos="fade-left" data-aos-duration="1800">
                                                <ul class="nav nav-pills nav-justified">
                                                    <li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
                                                    <li class="nav-item"><i class="fab fa-vuejs"></i>Vue Js</li>
                                                    <li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
                                                    <li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
                                                    <li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
                                                </ul>
                                            </p>    
                                        </div>
                                    </div>
                                </div> 
                            </div>
                            <div class="carousel-item">
                                <div class="row">
                                    <div class="col-md-6 portfolio_item_right">
                                        <img src="/assets/d9_images/webp/mi_education.webp" alt="" title="">
                                    </div>
                                    <div class="col-md-6 portfolio_item_left">
                                        <div class="homeportfolio_content">
                                            <h1 class="text_big" data-aos="fade-left" data-aos-duration="1000">Sama AL Nokhba Training Center</h1>
                                            <p class="text_normal" data-aos="fade-left" data-aos-duration="1200">Sama AL-Nokhba training center provide essential services for the sucess of aspiring ondividuals with direct training or smart training techniques.<br/></p>
                                            <p class="text_sub" data-aos="fade-left" data-aos-duration="1500"><br/>Used Technology</p>
                                            <p class="text_normal" data-aos="fade-left" data-aos-duration="1800">
                                                <ul class="nav nav-pills nav-justified">
                                                    <li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
                                                    <li class="nav-item"><i class="fab fa-vuejs"></i>Vue Js</li>
                                                    <li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
                                                    <li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
                                                    <li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
                                                </ul>
                                            </p>    
                                        </div>
                                    </div>
                                </div> 
                            </div>
                            <div class="carousel-item">
                                <div class="row">
                                    <div class="col-md-6 portfolio_item_right">
                                        <img src="/assets/d9_images/point_click.png" alt="" title="">
                                    </div>
                                    <div class="col-md-6 portfolio_item_left">
                                        <div class="homeportfolio_content">
                                            <h1 class="text_big" data-aos="fade-left" data-aos-duration="1000">Point click & Design</h1>
                                            <p class="text_normal" data-aos="fade-left" data-aos-duration="1200">This Point click & design site based in custome texture design. The site offers quality of products for peoples.<br/></p>
                                            <p class="text_sub" data-aos="fade-left" data-aos-duration="1500"><br/>Used Technology</p>
                                            <p class="text_normal" data-aos="fade-left" data-aos-duration="1800">
                                                <ul class="nav nav-pills nav-justified">
                                                    <li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
                                                    <li class="nav-item"><i class="fab fa-vuejs"></i>Vue Js</li>
                                                    <li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
                                                    <li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
                                                    <li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
                                                </ul>
                                            </p>    
                                        </div>
                                    </div>
                                </div> 
                            </div>
                            <div class="carousel-item">
                                <div class="row">
                                    <div class="col-md-6 portfolio_item_right">
                                        <img src="/assets/d9_images/webp/pifcoin_1.webp" alt="" title="">
                                    </div>
                                    <div class="col-md-6 portfolio_item_left">
                                        <div class="homeportfolio_content">
                                            <h1 class="text_big" data-aos="fade-left" data-aos-duration="1000">Pifcoin</h1>
                                            <p class="text_normal" data-aos="fade-left" data-aos-duration="1200">Pifcoin is a means to track, inspire and most importantly, promote paying acts of kindness forward. The goal is to further advocate the "pay it forward" agenda by physically using a coin passed from one person to the next.<br/></p>
                                            <p class="text_sub" data-aos="fade-left" data-aos-duration="1500"><br/>Used Technology</p>
                                            <p class="text_normal" data-aos="fade-left" data-aos-duration="1800">
                                                <ul class="nav nav-pills nav-justified">
                                                    <li class="nav-item"><i class="fab fa-laravel"></i>Laravel</li>
                                                    <li class="nav-item"><i class="fab fa-html5"></i>HTML 5</li>
                                                    <li class="nav-item"><i class="fab fa-css3-alt"></i>CSS 3</li>
                                                    <li class="nav-item"><i class="fab fa-bootstrap"></i>Bootstrap</li>
                                                </ul>
                                            </p>    
                                        </div>
                                    </div>
                                </div> 
                            </div>
                        </div>
                        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                            <i class="fas fa-long-arrow-alt-left"></i>
                        </a>
                        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                            <i class="fas fa-long-arrow-alt-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>  
    </div>
</template>

<script>
    export default {
        components: {
        },
        data: () => ({
            show: false
        }),
        mounted(){
            
        }
    };
    
</script>
