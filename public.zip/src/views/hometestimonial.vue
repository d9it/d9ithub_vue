<template>
    <div>
        <div class="home_testimonial">
            <!-- Testimonial Section -->
            <section class="testimonial_section">
                <div class="container">
                    <div class="sec_title">
                        <span class="title" data-aos="zoom-in" data-aos-duration="1000">Testimonial</span>
                        <h2 data-aos="zoom-in" data-aos-duration="1500">What Our core client say ?</h2>
                    </div>
                    <div id="client" class="carousel slide" data-ride="carousel">
                        <!-- The slideshow -->
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <div class="testimonial_content" data-aos="flip-up" data-aos-duration="1500">
                                    <p class="mb-5">
                                        The team at D9ithub has been instrumental in assisting me with various business/technology projects. They are experts in their craft and have delivered very elegant solutions in very tight time constraints. From general business consulting to software solutions they are the team I count on for everything.
                                    </p>
                                    <h3 class="devider-bottom">Edwin Huberdeau</h3>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="testimonial_content" data-aos="flip-up" data-aos-duration="1500">
                                    <p class="mb-5">
                                        My account manager was Dhruv at D9ithub. My project involved simple IT tasks and website compressing that I was afraid to go ahead with. The website compressing significantly improved the speed on the desktop viewing . Dhruv responded to my emails/questions promptly. I would strongly recommended his services.
                                    </p>
                                    <h3 class="devider-bottom">Lea Sears</h3>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="testimonial_content" data-aos="flip-up" data-aos-duration="1500">
                                    <p class="mb-5">
                                        I have hired them for a number of web development tasks, and have been consistently impressed in all aspects -- efficient, high quality, and well-priced.  Highly recommend.
                                    </p>
                                    <h3 class="devider-bottom">Reece Sellin</h3>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="testimonial_content" data-aos="flip-up" data-aos-duration="1500">
                                    <p class="mb-5">
                                        Working with D9 has been great!  I needed help with a tricky e-commerce coding issue, and they not only resolved the issue, but have also provided other services to support developing and optimizing my clients' sites.  Communication is great, and the quality of work is first class. They come highly recommend by me!
                                    </p>
                                    <h3 class="devider-bottom">Lisa Gibson</h3>
                                </div>
                            </div>
                            <div class="carousel-item ">
                                <div class="testimonial_content" data-aos="flip-up" data-aos-duration="1500">
                                    <p class="mb-5">
                                        I have had d9ithub perform many projects for me and they have completed all of them on time and with great quality, I continue to use them exclusively.
                                    </p>
                                    <h3 class="devider-bottom">Dean Jones</h3>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="testimonial_content" data-aos="flip-up" data-aos-duration="1500">
                                    <p class="mb-5">
                                        Has been very helpful and completed tasks in a timely fashion to a good standard. Will use again and again
                                    </p>
                                    <h3 class="devider-bottom">Danielle McCarthy</h3>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="testimonial_content" data-aos="flip-up" data-aos-duration="1500">
                                    <p class="mb-5">
                                        Great communicator, efficient and attentive to clients details and needs. Definitely recommend and will use for future projects!
                                    </p>
                                    <h3 class="devider-bottom">Renee J-Allen</h3>
                                </div>
                            </div>                                        
                        </div>

                        <a class="carousel-control-prev" href="#client" role="button" data-slide="prev">
                            <i class="fas fa-long-arrow-alt-left"></i>
                        </a>
                        <a class="carousel-control-next" href="#client" role="button" data-slide="next">
                            <i class="fas fa-long-arrow-alt-right"></i>
                        </a>
                    </div>
                    <div class="thumb_layer paroller">
                        <figure class="image"><img src="/assets/d9_images/testimonial_bg.png" alt=""></figure>
                    </div>
                </div>
            </section>
        </div>
    </div>
</template>

<script>
    export default {
        components: {
        },
        data: () => ({
            show: false
        }),
    };
    
</script>